﻿import {Component} from '@angular/core';
import {Router} from '@angular/router';

import {AuthenticationService} from './_services';
import {User} from './_models';

import './_content/app.less';

@Component({selector: 'app', templateUrl: 'app.component.html'})
export class AppComponent {
  currentUser: User;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private logger: NGXLogger
  ) {
    this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    this.logger.debug("Debug message");
    this.logger.info("Info message");
    this.logger.log("Default log message");
    this.logger.warn("Warning message");
    this.logger.error("Error message");
  }

  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/login']);
  }
}
